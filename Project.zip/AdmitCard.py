import mysql.connector as sqlcon

sn = int(input('Enter your Roll Number : '))

con=sqlcon.connect(host='localhost',user='root',password='123456', database='project',charset='utf8')
mycur=con.cursor()
str1="Select StName from StReg where RollNo = '"+str(sn)+"'"
mycur.execute(str1)
data=mycur.fetchall()
for r in data:
    print(r)
con.close()
   
con=sqlcon.connect(host='localhost',user='root',password='123456', database='project',charset='utf8')
mycur=con.cursor() 
strf="Select FName from StReg where RollNo = '"+str(sn)+"'"
mycur.execute(strf)
data=mycur.fetchall()
for f in data:
    print(f)
con.close() 

con=sqlcon.connect(host='localhost',user='root',password='123456', database='project',charset='utf8')
mycur=con.cursor() 
strm="Select MName from StReg where RollNo = '"+str(sn)+"'"
mycur.execute(strm)
data=mycur.fetchall()
for m in data:
    print(m)
con.close() 

con=sqlcon.connect(host='localhost',user='root',password='123456', database='project',charset='utf8')
mycur=con.cursor() 
strg="Select Gender from StReg where RollNo = '"+str(sn)+"'"
mycur.execute(strg)
data=mycur.fetchall()
for g in data:
    print(g)
con.close() 

con=sqlcon.connect(host='localhost',user='root',password='123456', database='project',charset='utf8')
mycur=con.cursor() 
strsn="Select SName from StReg where RollNo = '"+str(sn)+"'"
mycur.execute(strsn)
data=mycur.fetchall()
for sn in data:
    print(sn)
con.close() 




from tkinter import *
ticket = Tk()
ticket.title("Hall Ticket") 

ticket.geometry("1260x860")

Label(ticket, text="XYZ Exam Hall Ticket", font="BreeSerif 10 bold", padx=50, pady=7).place(x=60, y=10)
name = Label(ticket, text="Students Full Name", fg="red")
fname = Label(ticket, text="Fathers Name", fg="red")
mname = Label(ticket, text="Mothers Name", fg="red")
gender = Label(ticket, text="Gender", fg="red")
sname = Label(ticket, text="School Name", fg="red") 

name.place(x=10, y=40)
fname.place(x=10, y=80)
mname.place(x=10, y=120)
gender.place(x=10, y=160)
sname.place(x=10, y=200)

nameentry = Label(ticket, text=r)
fnameentry = Label(ticket, text=f)
mnameentry = Label(ticket, text=m)
genderentry = Label(ticket, text=g)
snameentry = Label(ticket, text=sn)


nameentry.place(x=140, y=40)
fnameentry.place(x=140, y=80)
mnameentry.place(x=140, y=120)
genderentry.place(x=140, y=160)
snameentry.place(x=140, y=200)





ticket.mainloop()
