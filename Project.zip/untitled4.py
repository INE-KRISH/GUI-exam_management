from tkinter import *
import mysql.connector as sc

root = Tk()

def getvals():
    sn = nameentry.get()
    fn = fnameentry.get()
    mn = mnameentry.get() 
    ge = genderentry.get()
    cn = snameentry.get()
    conn=sc.connect(host='localhost',user='root',password='123456',database='project',charset='utf8')
    cur=conn.cursor()
    savedata="insert into StReg(StName, FName, MName, Gender, SName) values(%s, %s, %s, %s, %s)"
    val = (sn, fn, mn, ge, cn)
    cur.execute(savedata,val)
    conn.commit()
    print('Record Saved Successfuly') 
    conn.close()
    
    

def RollNum():
    
    sn = nameentry.get() 
    cn = snameentry.get()
    conn=sc.connect(host='localhost',user='root',password='123456',database='project',charset='utf8')
    cur=conn.cursor()
    str1="Select RollNo from Streg where StName='"+sn+"' and SName= '"+cn+"'"
    cur.execute(str1)
    data=cur.fetchall()
    for r in data:
        print(r)  
    conn.close() 
    

root.geometry("300x300")
root.minsize(300,230)
root.maxsize(300,230)

root.title("IP PROJECT")

Label(root, text="Exam Registration Portal", font="BreeSerif 10 bold", pady=10).grid(row=0, column=3)

#Text for our form
name = Label(root, text="Students Full Name", fg="red")
fname = Label(root, text="Fathers Name", fg="red")
mname = Label(root, text="Mothers Name", fg="red")
gender = Label(root, text="Gender", fg="red")
sname = Label(root, text="School Name", fg="red")


#Pack text for our form
name.grid(row=1, column=2)
fname.grid(row=2, column=2)
mname.grid(row=3, column=2)
gender.grid(row=4, column=2)
sname.grid(row=5,column=2) 


# Tkinter variable for storing entries
namevalue = StringVar()
fnamevalue = StringVar()
mnamevalue = StringVar()
gendervalue = StringVar()
snamevalue = StringVar()


#Entries for our form
nameentry = Entry(root, textvariable=namevalue)
fnameentry = Entry(root, textvariable=fnamevalue)
mnameentry = Entry(root, textvariable=mnamevalue)
genderentry = Entry(root, textvariable=gendervalue)
snameentry = Entry(root, textvariable=snamevalue)

# Packing the Entries
nameentry.grid(row=1, column=3)
fnameentry.grid(row=2, column=3)
mnameentry.grid(row=3, column=3)
genderentry.grid(row=4, column=3)
snameentry.grid(row=5, column=3)

#Button & packing it and assigning it a command
Button(text="Submit the form", command=getvals).grid(row=6, column=3, pady=5) 
Button(text="Get your Roll Number", command=RollNum).grid(row=7, column=3, pady=5) 


root.mainloop()